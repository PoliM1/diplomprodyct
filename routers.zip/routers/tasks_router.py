# routers/tasks_router.py
import os
import uuid
from typing import Optional, List
from datetime import datetime, timedelta

import aiofiles
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import text as sa_text

from database import get_db
from models import Task, TaskFile, OrgMember, TaskStatusEnum, User
from auth import get_current_user

router = APIRouter(prefix="/tasks", tags=["Задачи"])

# Роли с расширенными правами (как у boss/manager)
SENIOR_ROLES = {'boss', 'manager', 'deputy', 'assistant'}

def get_role_str(user) -> str:
    return str(user.role.value if hasattr(user.role, 'value') else user.role)

def is_senior(user) -> bool:
    """Руководитель, менеджер, заместитель или помощник."""
    return get_role_str(user) in SENIOR_ROLES

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {".docx",".doc",".xlsx",".xls",".pdf",".txt",".accdb",".mdb"}
MIME_TYPES = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc":  "application/msword",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls":  "application/vnd.ms-excel",
    ".pdf":  "application/pdf",
    ".txt":  "text/plain",
    ".accdb":"application/msaccess",
    ".mdb":  "application/msaccess",
}

# Сколько дней хранятся принятые/отклонённые/просроченные задачи
ARCHIVE_DAYS = 1


def check_org_membership(user_id: int, org_id: int, db: Session) -> bool:
    return db.query(OrgMember).filter(
        OrgMember.user_id == user_id,
        OrgMember.org_id  == org_id,
        OrgMember.is_accepted == True,
    ).first() is not None


def task_to_dict(task: Task) -> dict:
    status = task.status.value if hasattr(task.status, 'value') else str(task.status)
    try:
        files = [{
            "id":   f.id,
            "name": f.filename,
            "type": f.file_type,
        } for f in (task.attachments or [])]
    except Exception:
        files = []
    return {
        "id":             task.id,
        "title":          task.title,
        "description":    task.description,
        "status":         status,
        "deadline":       task.deadline.strftime("%Y-%m-%d %H:%M") if task.deadline else None,
        "review_comment": task.review_comment,
        "created_at":     str(task.created_at),
        "is_deleted":     bool(getattr(task, "is_deleted", False)),
        "deleted_at":     str(task.deleted_at) if getattr(task, "deleted_at", None) else None,
        "creator":  {"id": task.creator_id,  "name": task.creator.full_name  if task.creator  else "?"},
        "assignee": {"id": task.assignee_id, "name": task.assignee.full_name if task.assignee else None},
        "reviewer": {"id": task.reviewer_id, "name": task.reviewer.full_name if task.reviewer else None},
        "files":    files,
    }


def run_auto_maintenance(db: Session, client_offset_minutes: int = 0):
    """
    1. Помечает просроченные активные задачи как overdue
    2. Мягко удаляет задачи completed/rejected/overdue старше ARCHIVE_DAYS дней
    
    client_offset_minutes: смещение часового пояса клиента в минутах (например, +180 для UTC+3).
    Если передан — используем время клиента. Иначе берём серверное время.
    """
    from datetime import timezone, timedelta as td
    # Вычисляем "сейчас" в часовом поясе клиента
    if client_offset_minutes != 0:
        tz_client = timezone(td(minutes=client_offset_minutes))
        now = datetime.now(tz=tz_client).replace(tzinfo=None)
    else:
        now = datetime.now()

    # 1. Активные задачи с истёкшим дедлайном → overdue (буфер 1 минута)
    grace = (now - timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M:%S")
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    db.execute(sa_text("""
        UPDATE tasks
        SET status = 'overdue', updated_at = :now
        WHERE deadline IS NOT NULL
          AND deadline < :grace
          AND status IN ('pending', 'in_progress', 'on_review')
          AND (is_deleted IS NULL OR is_deleted = 0)
    """), {"now": now_str, "grace": grace})

    # 2. Старые завершённые/отклонённые/просроченные → soft delete
    cutoff = (now - timedelta(days=ARCHIVE_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
    db.execute(sa_text("""
        UPDATE tasks
        SET is_deleted = 1, deleted_at = :now
        WHERE status IN ('completed', 'rejected', 'overdue')
          AND (is_deleted IS NULL OR is_deleted = 0)
          AND (
              (status IN ('completed','rejected') AND updated_at IS NOT NULL AND updated_at < :cutoff)
              OR
              (status = 'overdue' AND deadline IS NOT NULL AND deadline < :cutoff)
          )
    """), {"now": now_str, "cutoff": cutoff})

    db.commit()


# ── Создать задачу ────────────────────────────────────────────────────────────
def _parse_deadline(s: str):
    """Парсит строку дедлайна. Хранит локальное время клиента как есть."""
    if not s:
        return None
    s = s.strip().replace('T', ' ')
    # Убираем секунды/миллисекунды/timezone суффиксы
    s = s[:16]  # "YYYY-MM-DD HH:MM"
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M")
    except ValueError:
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d")
        except ValueError:
            return None

@router.post("/create")
async def create_task(
    title:       str           = Form(...),
    description: str           = Form(""),
    org_id:      int           = Form(...),
    assignee_id: Optional[int] = Form(None),
    reviewer_id: Optional[int] = Form(None),
    deadline:    Optional[str] = Form(None),
    files:       List[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not check_org_membership(current_user.id, org_id, db):
        raise HTTPException(403, "Вы не состоите в этой организации")

    task = Task(
        title=title, description=description, org_id=org_id,
        creator_id=current_user.id, assignee_id=assignee_id,
        reviewer_id=reviewer_id,
        deadline=_parse_deadline(deadline) if deadline else None,
    )
    db.add(task)
    db.flush()

    saved = []
    for file in files:
        if not file.filename:
            continue
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            continue
        uname = f"{uuid.uuid4()}{ext}"
        fpath = os.path.join(UPLOAD_DIR, uname)
        async with aiofiles.open(fpath, "wb") as f:
            await f.write(await file.read())
        db.add(TaskFile(task_id=task.id, uploader_id=current_user.id,
                        filename=file.filename, file_path=fpath, file_type="task_file"))
        saved.append(file.filename)

    db.commit()
    return {"id": task.id, "message": "Задача создана", "files_attached": saved}


# ── Задачи организации ────────────────────────────────────────────────────────
@router.get("/org/{org_id}")
def get_org_tasks(org_id: int,
                  tz_offset: int = 0,
                  db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    if not check_org_membership(current_user.id, org_id, db):
        raise HTTPException(403, "Нет доступа к этой организации")

    run_auto_maintenance(db, client_offset_minutes=tz_offset)

    rows = db.execute(
        sa_text("""
            SELECT id FROM tasks
            WHERE org_id = :org_id
              AND (is_deleted IS NULL OR is_deleted = 0)
            ORDER BY created_at DESC
        """),
        {"org_id": org_id}
    ).fetchall()

    task_ids = [r[0] for r in rows]
    if not task_ids:
        return []
    tasks = db.query(Task).filter(Task.id.in_(task_ids)).order_by(Task.created_at.desc()).all()
    return [task_to_dict(t) for t in tasks]


# ── Мои задачи ────────────────────────────────────────────────────────────────
@router.get("/my")
def get_my_tasks(db: Session = Depends(get_db),
                 current_user: User = Depends(get_current_user)):
    tasks = db.query(Task).filter(
        (Task.assignee_id == current_user.id) | (Task.reviewer_id == current_user.id),
        (Task.is_deleted == False) | (Task.is_deleted == None)
    ).order_by(Task.created_at.desc()).all()
    return [task_to_dict(t) for t in tasks]


# ── Удалённые задачи (только мои) ────────────────────────────────────────────
@router.get("/deleted/{org_id}")
def get_deleted_tasks(org_id: int, db: Session = Depends(get_db),
                      current_user: User = Depends(get_current_user)):
    if not check_org_membership(current_user.id, org_id, db):
        raise HTTPException(403, "Нет доступа")

    rows = db.execute(
        sa_text("""
            SELECT id FROM tasks
            WHERE org_id = :org_id
              AND creator_id = :uid
              AND is_deleted = 1
            ORDER BY deleted_at DESC
        """),
        {"org_id": org_id, "uid": current_user.id}
    ).fetchall()

    task_ids = [r[0] for r in rows]
    if not task_ids:
        return []
    tasks = db.query(Task).filter(Task.id.in_(task_ids)).all()
    return [task_to_dict(t) for t in tasks]


# ── Мягкое удаление ──────────────────────────────────────────────────────────
@router.post("/delete/{task_id}")
def soft_delete_task(task_id: int, db: Session = Depends(get_db),
                     current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if task.creator_id != current_user.id and not is_senior(current_user):
        raise HTTPException(403, "Только создатель или руководитель может удалить задачу")
    db.execute(
        sa_text("UPDATE tasks SET is_deleted = 1, deleted_at = :now WHERE id = :tid"),
        {"now": datetime.now().isoformat(), "tid": task_id}
    )
    db.commit()
    return {"message": "Задача перемещена в удалённые"}


# ── Очистить корзину ──────────────────────────────────────────────────────────
@router.delete("/trash/{org_id}")
def clear_trash(org_id: int, db: Session = Depends(get_db),
                current_user: User = Depends(get_current_user)):
    db.execute(sa_text("""
        DELETE FROM task_files WHERE task_id IN (
            SELECT id FROM tasks
            WHERE org_id = :oid AND creator_id = :uid AND is_deleted = 1
        )
    """), {"oid": org_id, "uid": current_user.id})
    result = db.execute(sa_text("""
        DELETE FROM tasks
        WHERE org_id = :oid AND creator_id = :uid AND is_deleted = 1
    """), {"oid": org_id, "uid": current_user.id})
    db.commit()
    return {"message": "Корзина очищена", "deleted": result.rowcount}


# ── Восстановить задачу ───────────────────────────────────────────────────────
@router.post("/{task_id}/restore")
def restore_task(task_id: int, db: Session = Depends(get_db),
                 current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if task.creator_id != current_user.id:
        raise HTTPException(403, "Только создатель может восстановить задачу")
    db.execute(
        sa_text("UPDATE tasks SET is_deleted = 0, deleted_at = NULL, status = 'pending' WHERE id = :tid"),
        {"tid": task_id}
    )
    db.commit()
    return {"message": "Задача восстановлена"}


# ── Одна задача ───────────────────────────────────────────────────────────────
@router.get("/{task_id}")
def get_task(task_id: int, db: Session = Depends(get_db),
             current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if not check_org_membership(current_user.id, task.org_id, db):
        raise HTTPException(403, "Нет доступа")
    return task_to_dict(task)


# ── Изменить статус ───────────────────────────────────────────────────────────
@router.patch("/{task_id}/status")
def update_status(task_id: int, status: str, comment: Optional[str] = None,
                  db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if not check_org_membership(current_user.id, task.org_id, db):
        raise HTTPException(403, "Нет доступа")

    valid = [s.value for s in TaskStatusEnum]
    if status not in valid:
        raise HTTPException(400, f"Статус должен быть одним из: {valid}")

    if status in ("completed", "rejected"):
        # Senior roles (boss/manager/deputy/assistant) могут принять/отклонить любую задачу
        if not is_senior(current_user):
            if not task.reviewer_id:
                raise HTTPException(400, "У задачи нет проверяющего")
            if task.reviewer_id != current_user.id:
                raise HTTPException(403, "Только проверяющий или руководитель может принять/отклонить задачу")

    if status == "in_progress" and task.assignee_id:
        # Senior roles могут взять любую задачу в работу
        if not is_senior(current_user) and task.assignee_id != current_user.id:
            raise HTTPException(403, "Только исполнитель может взять задачу в работу")

    db.execute(
        sa_text("UPDATE tasks SET status = :status, updated_at = :now WHERE id = :tid"),
        {"status": status, "now": datetime.now().isoformat(), "tid": task_id}
    )
    if comment:
        db.execute(sa_text("UPDATE tasks SET review_comment = :c WHERE id = :tid"),
                   {"c": comment, "tid": task_id})
    db.commit()
    return {"message": "Статус обновлён", "new_status": status}


# ── Загрузить результат ───────────────────────────────────────────────────────
@router.post("/{task_id}/upload-result")
async def upload_result(task_id: int, file: UploadFile = File(...),
                        db: Session = Depends(get_db),
                        current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if not check_org_membership(current_user.id, task.org_id, db):
        raise HTTPException(403, "Нет доступа")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Недопустимый тип файла")

    uname = f"{uuid.uuid4()}{ext}"
    fpath = os.path.join(UPLOAD_DIR, uname)
    async with aiofiles.open(fpath, "wb") as f:
        await f.write(await file.read())

    db.add(TaskFile(task_id=task.id, uploader_id=current_user.id,
                    filename=file.filename, file_path=fpath, file_type="result_file"))
    db.execute(sa_text("UPDATE tasks SET status = 'on_review', updated_at = :now WHERE id = :tid"),
               {"now": datetime.now().isoformat(), "tid": task_id})
    db.commit()
    return {"message": "Результат загружен. Задача отправлена на проверку."}


# ── Скачать файл ──────────────────────────────────────────────────────────────
@router.get("/file/{file_id}/download")
def download_file(file_id: int, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    tf = db.query(TaskFile).filter(TaskFile.id == file_id).first()
    if not tf:
        raise HTTPException(404, "Файл не найден")
    if not check_org_membership(current_user.id, tf.task.org_id, db):
        raise HTTPException(403, "Нет доступа")
    if not os.path.exists(tf.file_path):
        raise HTTPException(404, "Файл не найден на сервере")

    ext = os.path.splitext(tf.filename)[1].lower()
    return FileResponse(path=tf.file_path, filename=tf.filename,
                        media_type=MIME_TYPES.get(ext, "application/octet-stream"))

@router.patch("/{task_id}/reassign")
def reassign_task(task_id: int,
                  assignee_id: Optional[int] = None,
                  reviewer_id: Optional[int] = None,
                  db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    """Смена исполнителя/проверяющего. Только boss/manager или создатель задачи."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(404, "Задача не найдена")
    if not check_org_membership(current_user.id, task.org_id, db):
        raise HTTPException(403, "Нет доступа")
    if not is_senior(current_user) and task.creator_id != current_user.id:
        raise HTTPException(403, "Только руководитель или создатель может менять исполнителя")
    parts = []
    if assignee_id is not None:
        parts.append("assignee_id = :aid")
    if reviewer_id is not None:
        parts.append("reviewer_id = :rid")
    if not parts:
        raise HTTPException(400, "Укажите assignee_id или reviewer_id")
    params = {"tid": task_id}
    if assignee_id is not None: params["aid"] = assignee_id if assignee_id != 0 else None
    if reviewer_id is not None: params["rid"] = reviewer_id if reviewer_id != 0 else None
    db.execute(sa_text(f"UPDATE tasks SET {', '.join(parts)} WHERE id = :tid"), params)
    db.commit()
    # Return updated task
    db.expire_all()
    task = db.query(Task).filter(Task.id == task_id).first()
    return task_to_dict(task)


@router.post("/fix-overdue/{org_id}")
def fix_wrongly_overdue(org_id: int, db: Session = Depends(get_db),
                        current_user: User = Depends(get_current_user)):
    """Восстанавливает задачи которые были ошибочно помечены просроченными."""
    from sqlalchemy import text as sa_t
    now = datetime.now().isoformat()
    result = db.execute(sa_t("""
        UPDATE tasks SET status = 'pending', updated_at = :now
        WHERE org_id = :oid
          AND status = 'overdue'
          AND deadline > :now
          AND (is_deleted IS NULL OR is_deleted = 0)
    """), {"oid": org_id, "now": now})
    db.commit()
    return {"message": "Исправлено задач", "fixed": result.rowcount}