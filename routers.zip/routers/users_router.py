# routers/users_router.py
from fastapi import APIRouter, Depends, Query, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import text as sa_text
from database import get_db
from models import User, OrgMember, Task
from auth import get_current_user
from datetime import datetime, timedelta
from typing import Dict, Optional

router = APIRouter(prefix="/users", tags=["Пользователи"])

_online_users: Dict[int, datetime] = {}
ONLINE_TIMEOUT = 60

def mark_online(user_id: int):
    _online_users[user_id] = datetime.utcnow()

def is_online(user_id: int) -> bool:
    last = _online_users.get(user_id)
    return bool(last and (datetime.utcnow() - last).total_seconds() < ONLINE_TIMEOUT)


class ProfileUpdateBody(BaseModel):
    gender:     Optional[str] = None
    bio:        Optional[str] = None
    skills:     Optional[str] = None
    experience: Optional[str] = None
    avatar_url: Optional[str] = None


def user_to_dict(user: User, include_orgs: bool = False, db=None, current_id: int = None) -> dict:
    role = user.role.value if hasattr(user.role, 'value') else str(user.role)
    d = {
        "id":         user.id,
        "email":      user.email,
        "full_name":  user.full_name,
        "phone":      user.phone,
        "birth_date": user.birth_date,
        "position":   user.position,
        "role":       role,
        "avatar_url": getattr(user, 'avatar_url', None),
        "gender":     getattr(user, 'gender', None),
        "bio":        getattr(user, 'bio', None),
        "skills":     getattr(user, 'skills', None),
        "experience": getattr(user, 'experience', None),
        "created_at": str(user.created_at),
        "is_online":  is_online(user.id),
    }
    if include_orgs and db:
        memberships = db.query(OrgMember).filter(
            OrgMember.user_id == user.id,
            OrgMember.is_accepted == True,
        ).all()
        d["organizations"] = [
            {
                "id":       m.org.id,
                "name":     m.org.name,
                "description": m.org.description,
                "owner":    m.org.owner.full_name,
                "is_owner": m.org.owner_id == user.id,
            }
            for m in memberships
        ]
    return d


@router.get("/profile")
def get_profile(current_user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    mark_online(current_user.id)
    return user_to_dict(current_user, include_orgs=True, db=db, current_id=current_user.id)


@router.patch("/profile")
def update_profile(body: ProfileUpdateBody,
                   current_user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    """Обновляет профиль: аватар, пол, о себе, навыки, стаж."""
    updates = {k: v for k, v in body.dict().items() if v is not None}
    if not updates:
        return {"message": "Нечего обновлять"}

    set_parts = ", ".join(f"{k} = :{k}" for k in updates)
    updates["uid"] = current_user.id
    db.execute(sa_text(f"UPDATE users SET {set_parts} WHERE id = :uid"), updates)
    db.commit()
    # Refresh
    db.expire(current_user)
    return user_to_dict(current_user, include_orgs=True, db=db)


@router.get("/my-tasks")
def get_my_assigned_tasks(current_user: User = Depends(get_current_user),
                          db: Session = Depends(get_db)):
    """Задачи где текущий пользователь — исполнитель."""
    from models import TaskStatusEnum
    tasks = db.query(Task).filter(
        Task.assignee_id == current_user.id,
        (Task.is_deleted == False) | (Task.is_deleted == None)
    ).order_by(Task.created_at.desc()).all()

    result = []
    for t in tasks:
        status = t.status.value if hasattr(t.status, 'value') else str(t.status)
        result.append({
            "id":       t.id,
            "title":    t.title,
            "status":   status,
            "deadline": t.deadline.strftime("%Y-%m-%d %H:%M") if t.deadline else None,
            "org_name": t.org.name if t.org else "—",
            "creator":  t.creator.full_name if t.creator else "—",
            "reviewer": t.reviewer.full_name if t.reviewer else None,
        })
    return result


@router.get("/search")
def search_users(q: str = Query(..., min_length=2),
                 current_user: User = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    search = f"%{q}%"
    users = db.query(User).filter(
        (User.email.ilike(search)) | (User.full_name.ilike(search))
    ).filter(User.id != current_user.id).limit(10).all()
    return [{"id": u.id, "full_name": u.full_name, "email": u.email,
             "position": u.position, "role": u.role} for u in users]


@router.post("/heartbeat")
def heartbeat(current_user: User = Depends(get_current_user)):
    mark_online(current_user.id)
    return {"status": "ok"}


@router.get("/online")
def get_online_users(current_user: User = Depends(get_current_user)):
    mark_online(current_user.id)
    online_ids = [uid for uid, t in _online_users.items()
                  if (datetime.utcnow() - t).total_seconds() < ONLINE_TIMEOUT]
    return {"online": online_ids}


@router.get("/{user_id}/public")
def get_public_profile(user_id: int, db: Session = Depends(get_db),
                       current_user: User = Depends(get_current_user)):
    mark_online(current_user.id)
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "Пользователь не найден")
    return user_to_dict(user, db=db)


@router.get("/{user_id}/tasks")
def get_user_assigned_tasks(user_id: int, db: Session = Depends(get_db),
                            current_user: User = Depends(get_current_user)):
    """Задачи где user_id — исполнитель (для публичного профиля)."""
    tasks = db.query(Task).filter(
        Task.assignee_id == user_id,
        (Task.is_deleted == False) | (Task.is_deleted == None)
    ).order_by(Task.created_at.desc()).all()

    result = []
    for t in tasks:
        status = t.status.value if hasattr(t.status, 'value') else str(t.status)
        result.append({
            "id":       t.id,
            "title":    t.title,
            "status":   status,
            "deadline": t.deadline.strftime("%Y-%m-%d %H:%M") if t.deadline else None,
            "org_name": t.org.name if t.org else "—",
            "creator":  t.creator.full_name  if t.creator  else "—",
            "reviewer": t.reviewer.full_name if t.reviewer else None,
            "description": t.description or "",
            "review_comment": t.review_comment or "",
        })
    return result